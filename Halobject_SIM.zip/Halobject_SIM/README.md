# Halobject
The Simulation of Halobject in Simulator Gazebo.

The Gazebo model file is in Hal_ws.zip.

And Simulink model file is in ControllerModel_Simulink.zip.
libhector_gazebo_ros_sonar.so is the sonar plug-in at 1000 Hz.

please read the instruction Launch Manuel Halobject.pdf for details.